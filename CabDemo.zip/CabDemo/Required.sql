CREATE TABLE cab (cabId NUMBER PRIMARY KEY, name VARCHAR2 (20),pincode varchar2(10));




INSERT INTO cab VALUES(1001,'Tata Indica','6678454');
INSERT INTO cab VALUES(1002,'Indica','454');
INSERT INTO cab VALUES(1003,'Hyundai','6678');



CREATE TABLE cabcustomer(customerId NUMBER,name VARCHAR2(10),address VARCHAR2(10), phoneno VARCHAR2(12),regdate DATE, pin VARCHAR(6));



CREATE SEQUENCE customer_sequence
START WITH 1;