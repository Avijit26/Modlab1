package com.capgemini.CabDemo.bean;

import java.time.LocalDate;

public class CustomerBean {
	
	private int customerId;
	private String name;
	
	private String address;
	private String pin;
	
	private String phoneno;
	
	private LocalDate regdate;
	
	
	
	
	
	
	public CustomerBean() {
		super();
	}


	public CustomerBean(String name, String address,
			String pin, String phoneno, LocalDate regdate) {
		super();
		this.name = name;
		this.address = address;
		this.pin = pin;
		this.phoneno = phoneno;
		this.regdate = regdate;
	}


	public int getCustomerId() {
		return customerId;
	}


	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getPin() {
		return pin;
	}


	public void setPin(String pin) {
		this.pin = pin;
	}


	public String getPhoneno() {
		return phoneno;
	}


	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}


	public LocalDate getRegdate() {
		return regdate;
	}


	public void setRegdate(LocalDate regdate) {
		this.regdate = regdate;
	}


	@Override
	public String toString() {
		return "CustomerBean [customerId=" + customerId + ", name=" + name
				+ ", address=" + address + ", pin=" + pin + ", phoneno="
				+ phoneno + ", regdate=" + regdate + "]";
	}
	
	
	
	
	
	
	
}






	