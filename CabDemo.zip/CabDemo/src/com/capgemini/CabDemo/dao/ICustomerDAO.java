package com.capgemini.CabDemo.dao;

import com.capgemini.CabDemo.bean.CustomerBean;
import com.capgemini.CabDemo.exception.CabException;

public interface ICustomerDAO {
	
	public boolean insertCostomer(final CustomerBean customerBean) throws CabException;
	
	public int viewCabs(String pin) throws CabException;
	
	public int getId() throws CabException;

}
