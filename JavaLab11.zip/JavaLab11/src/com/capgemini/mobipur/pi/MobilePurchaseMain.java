package com.capgemini.mobipur.pi;

import java.time.LocalDate;

import com.capgemini.mobipur.bean.PurchaseDetailBean;
import com.capgemini.mobipur.exception.MobilePurchaseException;
import com.capgemini.mobipur.service.IServicePurchaseMobile;
import com.capgemini.mobipur.service.ServicePurchaseImpl;

public class MobilePurchaseMain {

	public static void main(String[] args) {
		PurchaseDetailBean pdb =new PurchaseDetailBean(1, "abc", "abc@gmail.com", "99", LocalDate.now(), 1002);
		
		IServicePurchaseMobile isp = new ServicePurchaseImpl();
		try{
			boolean isInserted = isp.insertPurchaseDetails(pdb);
			
			if(isInserted){
				System.out.println("Record inserted successfully!");
			}
			
			
		}catch(MobilePurchaseException mpe){
			System.out.println(mpe.getMessage());
		}
		

	}

}
