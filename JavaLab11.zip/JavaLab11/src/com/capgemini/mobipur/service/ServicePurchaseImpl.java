package com.capgemini.mobipur.service;

import com.capgemini.mobipur.bean.PurchaseDetailBean;
import com.capgemini.mobipur.dao.IMobileDAO;
import com.capgemini.mobipur.dao.IPurchaseDetailDAO;
import com.capgemini.mobipur.dao.MobileDAOImpl;
import com.capgemini.mobipur.dao.PurchaseDetailDAOImpl;
import com.capgemini.mobipur.exception.MobilePurchaseException;

public class ServicePurchaseImpl implements IServicePurchaseMobile {

	@Override
	public boolean insertPurchaseDetails(PurchaseDetailBean purchaseDetailBean) throws MobilePurchaseException {
		
		int mobileQuantity=0;
		boolean isItInserted= false;
		boolean isUpdated= false;
		
		
		IPurchaseDetailDAO purchaseDetailDAO= new PurchaseDetailDAOImpl();
		IMobileDAO mobileDAO = new MobileDAOImpl();
		
		
		mobileQuantity = mobileDAO.getQuantity(purchaseDetailBean.getMobileId());
		
		if(mobileQuantity>0)
		{
			
		
		isItInserted = purchaseDetailDAO.insertPurchase(purchaseDetailBean);
		
		mobileQuantity--;
		isUpdated =mobileDAO.updateMobile(purchaseDetailBean.getMobileId(),mobileQuantity);
		
		}
		return (isItInserted && isUpdated);
		
		 
		
	}
}

	