package com.capgemini.mobipur.dao;

public interface QueryMapperMobile {
	
	public static final String UPDATE_MOBILES = "UPDATE mobiles SET quantity=? WHERE mobileId=?";
	
	
	
	
	public static final String DELETE_MOBILES = "DELETE FROM mobiles WHERE mobileId=?";
	
	public static final String VIEW_MOBILES = "SELECT mobileId,name,price,quantity FROM mobiles";
	
	public static final String SEARCH_MOBILES = "SELECT mobileId,name,price,quantity FROM mobiles WHERE price BETWEEN ? AND ?";

	public static final String GET_MOBILES = "SELECT quantity FROM mobiles WHERE mobileId=? ";
	
	
}
