package com.capgemini.mobipur.dao;

import com.capgemini.mobipur.bean.PurchaseDetailBean;
import com.capgemini.mobipur.exception.MobilePurchaseException;

public interface IPurchaseDetailDAO {
	
	public boolean insertPurchase(final PurchaseDetailBean purchaseDetailsBean) throws MobilePurchaseException;
	
	public boolean deletePurchaseDetails(final int mobileId) throws MobilePurchaseException;
}