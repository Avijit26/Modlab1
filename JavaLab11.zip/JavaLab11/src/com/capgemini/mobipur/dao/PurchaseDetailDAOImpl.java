package com.capgemini.mobipur.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.capgemini.mobipur.bean.PurchaseDetailBean;
import com.capgemini.mobipur.exception.MobilePurchaseException;
import com.capgemini.mobipur.util.DBConnection;

public class PurchaseDetailDAOImpl implements IPurchaseDetailDAO {

	@Override
	public boolean insertPurchase(PurchaseDetailBean purchaseDetailBean)
			throws MobilePurchaseException {
		int records=0;
		boolean isInserted= false;
		
		
		try(Connection connPurchaseDetail = DBConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement=connPurchaseDetail.prepareStatement(QueryMapperPurchaseDetail.
				INSERT_PURCHASE);)
				{
					java.sql.Date purchaseDate= new Date(new java.util.Date().getTime());
					//preparedStatement.setInt(1,purchaseDetailBean.getPurchaseId()); 
					preparedStatement.setString(1,purchaseDetailBean.getName());
					preparedStatement.setString(2,purchaseDetailBean.getMailId());
					preparedStatement.setString(3,purchaseDetailBean.getPhoneNo());
					preparedStatement.setDate(4,purchaseDate);
					preparedStatement.setInt(5,purchaseDetailBean.getMobileId());
					
					records=preparedStatement.executeUpdate();
					
					
					if(records>0){
						isInserted=true;
					}
				}catch(SQLException sqlEx){
					throw new MobilePurchaseException(sqlEx.getMessage());
				}
		return isInserted;
	}
	
	

	@Override
	public boolean deletePurchaseDetails(int mobileId)
			throws MobilePurchaseException {
		
		
		int records=0;
		boolean isDeleted= false;
		
		
		try(Connection connPurchaseDetail = DBConnection.getInstance().getConnection();	
		PreparedStatement preparedStatement=connPurchaseDetail.prepareStatement(QueryMapperPurchaseDetail.
				DELETE_PURCHASE);)
				{
					
					preparedStatement.setInt(1,mobileId);
										
					records=preparedStatement.executeUpdate();
					
					
					if(records>0){
						isDeleted=true;
					}
				}catch(SQLException sqlEx){
					throw new MobilePurchaseException(sqlEx.getMessage());
				}
		return isDeleted;
		
		
		
		
		
	}

}
