package com.capgemini.EmployeeApplication.bean;

public class EmployeeBean {
	
	
	
		
		//private int employeeId;
		private String name;
		private int salary;
		private String doj;
		private String department;
		private String designation;
		public EmployeeBean() {
			super();
		}
		public EmployeeBean( String name, int salary, String doj, String department,String designation) {
			super();
			//this.employeeId = employeeId;
			this.name = name;
			this.salary = salary;
			this.doj=doj;
			this.department = department;
			this.designation = designation;
		}
		
		
		public String getDoj() {
			return doj;
		}
		public void setDoj(String doj) {
			this.doj = doj;
		}
		/*public int getEmployeeId() {
			return employeeId;
		}
		public void setEmployeeId(int employeeId) {
			this.employeeId = employeeId;
		}*/
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public long getSalary() {
			return salary;
		}
		public void setSalary(int salary) {
			this.salary = salary;
		}
		public String getDepartment() {
			return department;
		}
		public void setDepartment(String department) {
			this.department = department;
		}
		public String getDesignation() {
			return designation;
		}
		public void setDesignation(String designation) {
			this.designation = designation;
		}
		@Override
		public String toString() {
			return "Employee [name=" + name
					+ ", salary=" + salary + ", department=" + department
					+ ", designation=" + designation + "]";
		}
		
		
		
		
		
		
	}



