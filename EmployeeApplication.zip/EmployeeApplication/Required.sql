CREATE TABLE Employee (employeeId NUMBER PRIMARY KEY, name VARCHAR2 (20), salary NUMBER(10,2),department VARCHAR2(20),designation varchar(20));



CREATE SEQUENCE employeeId_seq START WITH 1001 INCREMENT BY 1;

INSERT INTO Employee VALUES(employeeId_seq.NEXTVAL,'Avijit',25000,'HR','Analys');

INSERT INTO Employee VALUES(employeeId_seq.NEXTVAL,'Arijit',35000,'EHR','EAnalys');

INSERT INTO Employee VALUES(employeeId_seq.NEXTVAL,'Ajit',45000,'THR','TAnalys');