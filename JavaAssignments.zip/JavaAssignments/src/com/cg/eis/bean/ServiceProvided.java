package com.cg.eis.bean;

public enum ServiceProvided {
	
	Scheme1,Scheme2,Scheme3,Scheme4

}
