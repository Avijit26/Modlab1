package com.cg.eis.bean;

public enum Designation {
	
	Manager, Banker,PO,Clerk

}
