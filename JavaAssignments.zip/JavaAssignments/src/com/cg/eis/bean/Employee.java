package com.cg.eis.bean;

public class Employee {
	public int id;
	public String name;
	public double salary;
	public Designation designation;
	public ServiceProvided insurenceScheme;
	
	
	public Employee() {
		super();
	}


	public Employee(int id, String name, double salary, Designation designation,
			ServiceProvided insurenceScheme) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.designation = designation;
		this.insurenceScheme = insurenceScheme;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public double getSalary() {
		return salary;
	}


	public void setSalary(double salary) {
		this.salary = salary;
	}


	public Designation getDesignation() {
		return designation;
	}


	public void setDesignation(Designation designation) {
		this.designation = designation;
	}


	public ServiceProvided getInsurenceScheme() {
		return insurenceScheme;
	}


	public void setInsurenceScheme(ServiceProvided insurenceScheme) {
		this.insurenceScheme = insurenceScheme;
	}


	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary
				+ ", designation=" + designation + ", insurenceScheme="
				+ insurenceScheme + "]";
	}
	
	
	
	

}


