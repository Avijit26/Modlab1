package com.cg.eis.pl;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.ServiceEmployee;

public class EmployeeMain {

	public static void main(String[] args) {
		
		Employee employee=new Employee();
		ServiceEmployee callerObj= new ServiceEmployee();
		
		callerObj.getEmployeeDetails(employee);
		callerObj.insurenceScheme(employee);
		callerObj.displayEmployeeDetails(employee);
		

	}

}
