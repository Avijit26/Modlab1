package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public interface IEmployeeService {

	
		public void getEmployeeDetails(Employee employee);
		public void insurenceScheme(Employee employee);
		public void displayEmployeeDetails(Employee employee);
}
