package com.cg.eis.service;

import java.util.Scanner;

import com.cg.eis.bean.Designation;
import com.cg.eis.bean.Employee;
import com.cg.eis.bean.ServiceProvided;

public class ServiceEmployee extends Employee  implements IEmployeeService {

	@Override
	public void getEmployeeDetails(Employee employee) {
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Employee Id: ");
		employee.setId(sc.nextInt());
		sc.nextLine();
		
		System.out.println("Enter Employee Name:");
		employee.setName(sc.nextLine());
		
		
		System.out.println("Enter The Salary of the Employee");
		employee.setSalary(sc.nextInt());
		
		double salary= employee.getSalary();
		if (salary>=1000 && salary<10000)
			employee.setDesignation(Designation.Clerk);
		else if (salary >=10000 && salary <20000)
			employee.setDesignation(Designation.PO);
		
		else if (salary >=20000 && salary <30000)
			employee.setDesignation(Designation.Banker);
		
		else if (salary >=30000 && salary <40000)
			employee.setDesignation(Designation.Manager);
		sc.close();
		
	}

	@Override
	public void insurenceScheme(Employee employee) {
		double salary= employee.getSalary();
		
		Designation designation = employee.getDesignation();
		
		if(salary>=1000 && salary<10000 && designation==Designation.Clerk)
			employee.setInsurenceScheme(ServiceProvided.Scheme4);
		
		if(salary>=10000 && salary>20000 && designation==Designation.PO)
			employee.setInsurenceScheme(ServiceProvided.Scheme3);
		
		if(salary>=20000 && salary<30000 && designation==Designation.Banker)
			employee.setInsurenceScheme(ServiceProvided.Scheme2);
		
		if(salary>=30000 && salary<40000 && designation==Designation.Manager)
			employee.setInsurenceScheme(ServiceProvided.Scheme1);
		}

	@Override
	public void displayEmployeeDetails(Employee employee) {
		
		System.out.println("Employee Details");
		System.out.println("--------------------------");
		System.out.println("Employee ID: " +employee.getId());
		System.out.println("Employee Name: " +employee.getName());
		System.out.println("Salary: " +employee.getSalary());
		System.out.println("Designation: " +employee.getDesignation());
		System.out.println("Insurance Scheme: " +employee.getInsurenceScheme());
		
		
		
	}

}
