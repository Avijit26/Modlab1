
public class PersonDetailsLab2 {
	String fName;
	String lName;
	String gender;
	int age;
	float weight;
	
	
	void Details()
	{
		System.out.println("Person Details");
		System.out.println("---------------");
		System.out.println("First Name:" +fName);
		System.out.println("Last Name:" +lName);
		System.out.println("Gender:" +gender);
		System.out.println("Age:" +age);
		System.out.println("Weight:" +weight);
	}

}
