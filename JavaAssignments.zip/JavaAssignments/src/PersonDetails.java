
public class PersonDetails {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		PersonDetails obj=new PersonDetails();
		//obj.Details();

	}

	

}
