package lab3;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;

public class TimeZoneDisplay {

	
	public static void main(String[] args){
		
		Scanner scinput = new Scanner(System.in);
		ZonedDateTime Tokyo = ZonedDateTime.now(ZoneId.of("Asia/Tokyo"));
		ZonedDateTime NewYork = ZonedDateTime.now(ZoneId.of("America/New_York"));
		ZonedDateTime London = ZonedDateTime.now(ZoneId.of("Europe/London"));
		ZonedDateTime Pacific = ZonedDateTime.now(ZoneId.of("US/Pacific"));
		System.out.println("Enter your time zone option");
		int option=scinput.nextInt();
		scinput.nextLine();
		
		switch(option)
		{
		case 1:
			System.out.println("Delhi:"+Tokyo);
			break;
		case 2:
			
			System.out.println("New York:" +NewYork);
			break;
		
		
		case 3:
			System.out.println("london:" +London);
			break;
			
		case 4:
			System.out.println("Pacific:" +Pacific);
			break;
	}
}
}
