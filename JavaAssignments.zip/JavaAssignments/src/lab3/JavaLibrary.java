package lab3;

import java.util.Scanner;

public class JavaLibrary {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);  
		// TODO Auto-generated method stub
		//int option=0;
		
		
		
		    

	    System.out.println( "1.Add the String To Itself" );
	    System.out.println( "2.Replace Odd Postions with #" );
	    System.out.println( "3.Remove duplicate character in the String" );
	    System.out.println( "4.Change odd characters to upper case" );
	    System.out.println("Enter You Choice");  
		int option=sc.nextInt(); 
		
		Options obj=new Options();
	    
	    
	    
	    switch (option){
	    
	    case 1: 
	    	obj.stringAddition();
	    	break;
	    	
	    case 2:
	    	obj.replaceOdds();
	    	break;
	    
	    case 3:
	    	System.out.println();
	    	break;
	    
	    case 4:
	    	System.out.println();
	    	break;
	    	
	    }
	    
		
		

	}

}



class Options{
				
	
				String string="What you want to do with this string";
				
				
				 void stringAddition()
				 {
					 System.out.println(string=string.concat(string));
					 
				 }
				 
				 void replaceOdds()
				 {
					 for (int i=0;i<string.length();i++)
					 {
						if(i%2==0)
						{
							string= string.substring(0,i-1)+ "#" + string.substring(i, string.length());
						}
					 	}
				 }

				 
				 void removeDuplicate()
				 {
					 System.out.println("Not Done Yet");
				 }
				 
				 
	
}
