package lab3;

import java.util.Scanner;

public class PositiveString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in); 
		
		String s= new String();
		
		System.out.println("Enter Your String");
		   
		  s =sc.nextLine();
		  
		  int length=s.length();
		  int flag=0;
		  for (int i=0;i<length-1;i++){
			  if(!((s.charAt(i))< (s.charAt(i+1)))){
				  flag=1;
				  break;
			  }
			  else
				  flag=0;
			  
				  
				  
		  }
		  if(flag==0){
			  System.out.println("Positive String");
		  }
			 else{
				  System.out.println("Negative String");
		  }
	}

}
