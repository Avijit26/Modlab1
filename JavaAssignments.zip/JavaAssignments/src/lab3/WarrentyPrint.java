package lab3;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class WarrentyPrint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner scinput= new Scanner(System.in);
		System.out.print("Enter Purchase date in dd/MM/yyyy format:");
		String purchaseDate  = scinput.nextLine();
	
		LocalDate enteredDate = LocalDate.parse(purchaseDate,formatter);
		//int warrentyDuration =2;
		System.out.print("Enter warrenty Duration in months:");
		int month  = scinput.nextInt();
		scinput.nextLine();
		System.out.print("Enter warrenty Duration in years:");
		int years  = scinput.nextInt();
		scinput.close();
		System.out.println("Last Date of warrenty expiration:" +enteredDate.plusYears(years).plusMonths(month));
		

	}

}
