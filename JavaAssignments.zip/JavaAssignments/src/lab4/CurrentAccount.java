package lab4;

public class CurrentAccount extends Account {
	
	public double overdraft=500;
	
	CurrentAccount(double balance, Person accHolder) {
		super(balance, accHolder);
	}
		
		
		public boolean withdraw(double amount)
		{
			double bal;
			if(this.getBalance()-amount>overdraft)
			{
				bal=this.getBalance()-amount;
				th
			}
				
				
		}
	}

