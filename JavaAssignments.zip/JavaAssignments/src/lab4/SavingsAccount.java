package lab4;

public class SavingsAccount extends Account  {
	
	public final double minBalance=500;

	SavingsAccount(double balance, Person accHolder) {
		super(balance, accHolder);
		
	}
	
	@Override
	public boolean withdraw(double amount)
	{	
		double mbal;
		if(this.getBalance()-amount> minBalance ){
		mbal=this.getBalance()-amount;
		this.setBalance(mbal);
		return true;
		}
		else{
			return false;
	}

}
}