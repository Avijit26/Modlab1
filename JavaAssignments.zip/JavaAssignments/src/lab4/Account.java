package lab4;

public abstract class Account {

	long accNum;
	double balance;
	public Person accHolder;
	
	public long getAccNum() {
		return accNum;
	}
	
	Account(double balance,Person accHolder)
	{
		this.balance=balance;
		this.accHolder=accHolder;
		
	}
	
	
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getAccHolder() {
		return accHolder;
	}
	public void setAccHolder(Person accHolder) {
		this.accHolder = accHolder;
	}
	
	public void deposit(double amount)
	{
		this.balance=this.balance+amount;
		
	}
	
	public abstract boolean withdraw(double amount);
	
	
	public String toString(){
		String text = "Account Number: " +accNum + "\n" +
						"Balance: "+balance + "\n" +
						"Holder Name: "+accHolder.getFirstName() + "\n" +
					  "===========================================================\n";
		return text;
	}
}
