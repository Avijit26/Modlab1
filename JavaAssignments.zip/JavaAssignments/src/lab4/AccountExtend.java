package lab4;

public class AccountExtend extends Account {

	AccountExtend(double balance, Person accHolder) {
		super(balance, accHolder);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean withdraw(double amount) {
		this.balance=this.balance-amount;
		return true;
	}

}
