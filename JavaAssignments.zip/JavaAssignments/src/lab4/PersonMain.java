package lab4;



public class PersonMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person obj=new Person("Avijit","Singh",Gender.M);
		Person obj1=new Person("Rahul","Sam",Gender.F);
		Account obj2=new Account(2000, obj);
		
		System.out.println("Balance Before:" +obj2.balance);
		obj2.deposit(2100);
		System.out.println("Balance After Dopesit:" +obj2.balance);
		obj2.withdraw(1400);
		System.out.println("Balance After Withdrawl:" +obj2.balance);
		obj2.toString();
		
		//obj.acceptPhoneNo();
		//obj.dob();
		//obj.Details();
	}

}
