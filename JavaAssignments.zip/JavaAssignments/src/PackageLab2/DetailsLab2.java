package PackageLab2;

public class DetailsLab2{
	String fName;
	String lName;
	String gender;
	int age;
	double weight;
	
	DetailsLab2(String fName,String lName,String gender,int age, double weight)
	{
		this.fName=fName;
		this.lName=lName;
		this.gender=gender;
		this.age=age;
		this.weight=weight;
	}
	
	
	void Details()
	{
		System.out.println("Person Details");
		System.out.println("---------------");
		System.out.println("First Name:" +fName);
		System.out.println("Last Name:" +lName);
		System.out.println("Gender:" +gender);
		System.out.println("Age:" +age);
		System.out.println("Weight:" +weight);
	}
	
	
	

	public static void main(String args[]){
	DetailsLab2 obj= new DetailsLab2("Avijit","Singh","male", 23,76.6);
	obj.Details();
	
}
}








