package PackageLab2;


public class PersonMain {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Person obj=new Person("Avijit","Singh",Gender.M);
		
		
		obj.acceptPhoneNo();
		obj.dob();
		obj.Details();
		
		
		
		
		
		
		

	}

}
