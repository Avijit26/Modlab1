package PackageLab2;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;
enum Gender {M,F};
public class Person {
	
	
	String  firstName;
	String lastName;
	Gender gender;
	long PhoneNo;
	int day,month,year;
	Scanner sc=new Scanner(System.in);
	
	Person()
	{
	
	}
	
	public Person(String firstName, String lastName, Gender gender)
	{
		this.firstName=firstName;
		this.lastName=lastName;
		this.gender=gender;
	}
	
	
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}
	
	
	
	
	public void acceptPhoneNo()
	{
		  
	     
		   System.out.println("Enter your Phone No");
		   
		   long PhoneNo=sc.nextLong();
		   this.PhoneNo=PhoneNo;
		   	
		
	}
	//Person p =new Person();
	
	
	public void dob()
	{

		DateTimeFormatter formatter =DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner scinput= new Scanner(System.in);
		System.out.println("Enter date in dd/mm/yyyy format:");
		String input  = scinput.nextLine();
	
		
		
		LocalDate enteredDate = LocalDate.parse(input,formatter);
		LocalDate end = LocalDate.now();
		
		Period period = enteredDate.until(end);
		scinput.close();
		this.day= period.getDays();
		this.month=period.getMonths();
		this.year= period.getYears();
		
		
		
		
		/*System.out.println("Days:"+ period.getDays());
		System.out.println("Months:"+period.getMonths());
		System.out.println("Years:"+ period.getYears());*/
		
		
	}
	
	
	public void Details()
	{
		System.out.println("Person Details");
		System.out.println("---------------");
		System.out.println("First Name:" +firstName);
		System.out.println("Last Name:" +lastName);
		System.out.println("Gender:" +gender);
		System.out.println("Phone No:" +PhoneNo);
		System.out.println("Year:" +year+ " Month " +month+" Day " +day );
		//System.out.println(day);
	}
	
	public static void main(String args[])
	{
		//Person Obj =new Person("Avijit","Singh",'M');
		//Obj.Details();
		
		
	}
	
	
}
