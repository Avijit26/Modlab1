package PackageLab2;




public class ShowDetails {

	public static void main(String[] args) {
		
		
		// TODO Auto-generated method stub
		ShowDetails obj=new ShowDetails();
		obj.Details();

	}

}
